# F2 > F2_all_parts
https://universe.roboflow.com/kwonyongjae/f2-0uiw2

Provided by a Roboflow user
License: CC BY 4.0

